package com.swings.golf.dto;

public class GolfCourseDTO {
}
