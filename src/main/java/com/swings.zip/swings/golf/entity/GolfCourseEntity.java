package com.swings.golf.entity;

public class GolfCourseEntity {
}
