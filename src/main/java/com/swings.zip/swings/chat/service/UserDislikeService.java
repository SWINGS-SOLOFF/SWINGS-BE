package com.swings.chat.service;

public interface UserDislikeService {
    void dislikeUser(String fromUsername, String toUsername);
}
