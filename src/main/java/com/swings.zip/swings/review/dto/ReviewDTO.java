package com.swings.review.dto;

public class ReviewDTO {
}
