package com.swings.chat.controller;

import com.swings.chat.dto.ChatRoomResponseDto;
import com.swings.chat.entity.ChatRoomEntity;
import com.swings.chat.service.ChatRoomService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/chat")
@RequiredArgsConstructor
public class ChatRoomController {

    private final ChatRoomService chatRoomService;

    // ✅ 1. 채팅방 목록 + 마지막 메시지 + 안 읽은 메시지 수 반환
    @GetMapping("/rooms")
    public List<ChatRoomResponseDto> getRooms(@RequestParam String userId) {
        return chatRoomService.getChatRoomsByUser(userId);
    }

    // ✅ 2. 채팅방 생성 or 조회
    @PostMapping("/room")
    public ResponseEntity<ChatRoomEntity> createOrGetChatRoom(@RequestParam String user1, @RequestParam String user2) {
        ChatRoomEntity chatRoom = chatRoomService.createOrGetChatRoom(user1, user2);
        return ResponseEntity.ok(chatRoom);
    }
}
